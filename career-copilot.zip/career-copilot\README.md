# Career Copilot — 职业副驾

证据驱动的 AI 求职操作系统。聚合多平台岗位、JD 深拆与匹配分析、AI 简历定制、投递管理与面试复盘，全流程可解释。

支持 **WorkBuddy** · **Claude Code** · **OpenAI Codex** · **OpenCode** 及任意 MCP 客户端接入。

## 类型

Agent 型（单个 AI 专家）

## 功能

1. **岗位发现与聚合** — 从 Greenhouse、Lever、Ashby、BOSS、LinkedIn、实习僧、牛客、智联、前程无忧、猎聘聚合岗位，硬过滤校招正式岗和收费培训
2. **JD 深拆与匹配分析** — 提取必备条件/加分项/隐性偏好，对照画像生成匹配证据与缺口清单
3. **AI 简历定制** — 基于真实项目证据生成岗位定制版简历，ATS 关键词覆盖率检查，A-C-R-E 审校
4. **投递管理与面试复盘** — 投递管线管理、面试准备包、结构化复盘、跟进提醒
5. **数据洞察与策略优化** — 渠道/地区/公司规模/简历版本转化率分析，周度回顾报告

## 使用示例

- "帮我分析岗位JD并定制简历"
- "我的求职进度怎么样？"
- "帮我准备即将到来的面试"

## 项目仓库

完整源码与部署指南：https://github.com/ronineymessjr-sudo/career-copilot

技术栈：Next.js 15 / React 19 / TypeScript / Cloudflare Workers / Supabase / pgvector / OpenAI Responses API

## 头像

头像已通过 ImageGen 自动生成在 `avatars/` 目录下。如需替换：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 安装

将专家包目录放到专家目录下：

```
~/.workbuddy/plugins/marketplaces/my-experts/plugins/career-copilot/
```

然后运行注册命令使其可见：

```bash
python3 scripts/register_expert.py <expert-dir> --session-id ba2bff83-a40b-4483-8058-1d4ca75b7e0e
```

## 打包分享

```bash
python3 scripts/package_expert.py <expert-dir>
```

## 许可证

MIT
